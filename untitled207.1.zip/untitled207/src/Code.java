import java.util.Scanner;

public class Code {
    private String code;
    private int id;
    private static int BaseId=1;
    Scanner scanner=new Scanner(System.in);
    public Code(String code) {
        this.code = code;
        this.id=BaseId++;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void make(){
        System.out.println("enter the code");
        this.code=scanner.next();
        this.id=BaseId++;
    }
    public Code(){make();}

    @Override
    public String toString() {
        return "Code{" +
                "code='" + code + '\'' +
                ", id=" + id +
                '}';
    }
}
