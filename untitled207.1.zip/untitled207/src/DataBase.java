import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class DataBase {
    ArrayList<Day>days;
    ArrayList<Time>times;
    ArrayList<NAme>nAmes;
    ArrayList<Code>codes;
    ArrayList<exam>exams;
    Scanner scanner=new Scanner(System.in);
    public DataBase() throws IOException {
        days=new ArrayList<>();
        times=new ArrayList<>();
        nAmes=new ArrayList<>();
        codes=new ArrayList<>();
        exams=new ArrayList<>();
        menu();
    }
    public void menu(){
        while (true){
            System.out.println("1.Add");
            System.out.println("2.check");
            System.out.println("3.show");
            System.out.println("4.remove by id:");
            System.out.println("5.save to txt file:");
            int ch=scanner.nextInt();
            switch (ch){
                case 1:
                    nAmes.add(new NAme());
                    days.add(new Day());
                    times.add(new Time());
                    codes.add(new Code());
                    exams.add(new exam());
                    break;
                case 2:
                    check();
                    checkexame();
                    break;
                case 3:
                    showall();
                    break;
                case 4:
                    removebyID();
                    break;
                case 5:
                    save_to_txt();
                    break;
                default:
                    System.out.println("Invalid choice");
            }


        }
    }


    public void showall(){
        for (int i = 0; i <nAmes.size() ; i++) {
            System.out.println(nAmes.get(i).toString());
            System.out.println(days.get(i).toString());
            System.out.println(times.get(i).toString());
            System.out.println(codes.get(i).toString());
            System.out.println(exams.get(i).toString());
        }
    }


    public void check(){
        for (int i = 0; i <days.size() ; i++) {
            for (int j = i+1; j <days.size() ; j++) {
                if(days.get(i).getDay().equals(days.get(j).getDay())){
                        if(times.get(i).getTime().equals(times.get(j).getTime())){
                            System.out.println("we have a problem");
                            System.out.println(nAmes.get(i).getName());
                            System.out.println(nAmes.get(j).getName());



                        }

                }

            }
        }
    }
    boolean flag=true;
    public void checkexame(){
        for (int i = 0; i <exams.size() ; i++) {
            for (int j = i+1; j < exams.size(); j++) {
                if(exams.get(i).getName().equals(exams.get(i).getName())){
                    System.out.println(exams.get(i).toString());
                    System.out.println(exams.get(i).toString());
                    flag=false;
                    break;
                }
            }
        }
    }

    FileWriter fileWriter=new FileWriter("test.txt");
    public void save_to_txt(){
        try {
            for (NAme nAme:nAmes){
                fileWriter.write(nAme.toString());

            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }



    public void removebyID(){
        System.out.println("enter the id to remove:");
        int idii=scanner.nextInt();
        for (NAme nAme:nAmes){
            if(idii==nAme.getId()){
                nAmes.remove(nAme);
                break;
            }
        }
        for (Day day:days){
            if(idii==day.getId()){
                days.remove(day);
                break;
            }
        }

        for (Time time:times){
            if(idii==time.getId()){
                times.remove(time);
                break;
            }
        }
        for (Code code:codes){
            if(idii==code.getId()){
                codes.remove(code);
                break;
            }
        }
        for (exam exam:exams){
            if(idii==exam.getId()){
                exams.remove(exam);
                break;
            }
        }

    }
}
