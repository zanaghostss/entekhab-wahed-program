import java.util.Scanner;

public class exam {
    private String name;

    private int id;
    private static int BaseId=1;
    Scanner scanner=new Scanner(System.in);
    public exam(String name) {
        this.name = name;
        this.id=BaseId++;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    public void make(){
        System.out.println("enetr the date of exam:");
        this.name=scanner.next();
        this.id=BaseId++;
    }
    public exam(){make();}

    @Override
    public String toString() {
        return "exam{" +
                "name='" + name + '\'' +
                ", id=" + id +
                '}';
    }
}
