import java.util.ArrayList;
import java.util.Scanner;

public class DataBase {
    ArrayList<Day>days;
    ArrayList<Time>times;
    ArrayList<NAme>nAmes;
    Scanner scanner=new Scanner(System.in);
    public DataBase(){
        days=new ArrayList<>();
        times=new ArrayList<>();
        nAmes=new ArrayList<>();
        menu();
    }
    public void menu(){
        while (true){
            System.out.println("1.Add");
            System.out.println("2.check");
            System.out.println("3.show");
            int ch=scanner.nextInt();
            switch (ch){
                case 1:
                    nAmes.add(new NAme());
                    days.add(new Day());
                    times.add(new Time());
                    break;
                case 2:
                    check();
                    break;
                case 3:
                    showall();
                    break;
                default:
                    System.out.println("Invalid choice");
            }


        }
    }


    public void showall(){
        for (int i = 0; i <nAmes.size() ; i++) {
            System.out.println(nAmes.get(i).toString());
            System.out.println(days.get(i).toString());
            System.out.println(times.get(i).toString());
        }
    }


    public void check(){
        for (int i = 0; i <days.size() ; i++) {
            for (int j = i+1; j <days.size() ; j++) {
                if(days.get(i).getDay().equals(days.get(j).getDay())){
                    if(times.get(i).getTime().equals(times.get(j).getTime())){
                        System.out.println("we have a problem");
                        System.out.println(nAmes.get(i).getName());
                        System.out.println(nAmes.get(j).getName());
                    }

                }
                else {
                    System.out.println("have no problem");
                }
            }
        }


    }
}
