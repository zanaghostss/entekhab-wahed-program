import java.util.Scanner;

public class Time {
    private String time;
    private int id;
    private static int BaseId=1;
    Scanner scanner=new Scanner(System.in);

    public Time(String time) {
        this.time = time;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void make(){
        System.out.println("enter the Time");
        this.time=scanner.next();
        this.id=BaseId++;
    }
    public Time(){
        make();
    }

    @Override
    public String toString() {
        return "Time{" +
                "time='" + time + '\'' +
                ", id=" + id +
                '}';
    }
}
