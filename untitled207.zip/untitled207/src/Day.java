import java.util.Scanner;

public class Day {
    private String day;
    private int id;
    private static int BaseId=1;

    Scanner scanner=new Scanner(System.in);
    public Day(String day) {
        this.day = day;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }
    public void make(){
        System.out.println("enter the day");
        this.day=scanner.next();
        this.id=BaseId++;
    }
    public Day(){make();}

    @Override
    public String toString() {
        return "Day{" +
                "day='" + day + '\'' +
                ", id=" + id +
                '}';
    }
}
