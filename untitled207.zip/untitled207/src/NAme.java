import java.util.Scanner;

public class NAme {
    public String name;
    private int id;
    private static int BaseID=1;
    Scanner scanner=new Scanner(System.in);
    public NAme(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void make(){
        System.out.println("enter the name:");
        this.name=scanner.next();
        this.id=BaseID++;
    }
    public NAme(){make();}

    @Override
    public String toString() {
        return "NAme{" +
                "name='" + name + '\'' +
                ", id=" + id +
                '}';
    }
}
